//
//  Menu2DictionaryItem.h
//  app_50hertz_clone
//
//  Created by Coeus on 06/03/2015.
//  Copyright (c) 2015 Coeus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Menu2DictionaryItem : NSObject

@property (strong, nonatomic) NSString * title;
@property (strong, nonatomic) NSString * file;
@property (strong, nonatomic) NSString * version;


@end
