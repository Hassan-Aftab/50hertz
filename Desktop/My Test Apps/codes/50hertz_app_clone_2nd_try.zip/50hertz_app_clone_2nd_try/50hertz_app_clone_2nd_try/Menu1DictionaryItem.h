//
//  Menu1DictionaryItem.h
//  app_50hertz_clone
//
//  Created by Coeus on 06/03/2015.
//  Copyright (c) 2015 Coeus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Menu2DictionaryItem.h"

@interface Menu1DictionaryItem : NSObject

@property (strong, nonatomic) NSString * title;
@property (strong, nonatomic) NSArray * menu2;

@end
