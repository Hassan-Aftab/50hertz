//
//  customCellMain.h
//  app_50hertz_clone
//
//  Created by Coeus on 06/03/2015.
//  Copyright (c) 2015 Coeus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customCellMain : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *backgroundImage;
@property (weak, nonatomic) IBOutlet UILabel *lblText;


@end
