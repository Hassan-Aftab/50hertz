//
//  Menu2DictionaryItem.m
//  app_50hertz_clone
//
//  Created by Coeus on 06/03/2015.
//  Copyright (c) 2015 Coeus. All rights reserved.
//

#import "Menu2DictionaryItem.h"

@implementation Menu2DictionaryItem

@end
