//
//  _0hertz_app_clone_2nd_tryTests.m
//  50hertz_app_clone_2nd_tryTests
//
//  Created by Coeus on 10/03/2015.
//  Copyright (c) 2015 Coeus. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _0hertz_app_clone_2nd_tryTests : XCTestCase

@end

@implementation _0hertz_app_clone_2nd_tryTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
